function w3c$dom$alert(wyString) {
    alert(js$util$from_string(wyString));
}
