function w3c$dom$alert(message) {
    alert(js$util$from_string(message));
}
