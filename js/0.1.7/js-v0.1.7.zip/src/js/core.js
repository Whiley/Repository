function js$core$append$Q6stringQ6string$Q6string(lhs, rhs) {
    return lhs + rhs;
}

function js$core$append$Q6stringQ3intQ6string(lhs, rhs) {
    return lhs + rhs;
}

function js$core$append$Q3intQ6numberQ6string(lhs, rhs) {
    return lhs + rhs;
}


function js$core$append$Q6stringQ6number$Q6string(lhs, rhs) {
    return lhs + rhs;
}

function js$core$append$Q6numberQ6string$Q6string(lhs, rhs) {
    return lhs + rhs;
}
