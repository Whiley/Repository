function js$JSON$parse(str) {
    return JSON.parse(str);
}

function js$JSON$stringify(item) {
    return JSON.stringify(item);
}
