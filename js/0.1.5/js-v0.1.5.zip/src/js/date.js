function js$date$now() {
    return Date.now();
}

function js$date$Date(ms) {
    return new Date(ms);
}
