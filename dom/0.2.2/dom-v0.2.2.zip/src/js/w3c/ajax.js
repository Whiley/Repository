function w3c$ajax$newXMLHttpRequest() {
    return new XMLHttpRequest();
}
