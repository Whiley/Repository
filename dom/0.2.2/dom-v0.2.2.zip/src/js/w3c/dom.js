function w3c$dom$alert(message) {
    alert(message);
}

function w3c$dom$setTimeout(callback,ms){
    setTimeout(callback,ms);
}

function w3c$dom$setInterval(callback, ms) {
    setInterval(callback,ms);
}

function w3c$dom$clearTimeout() {
    clearTimeout();
}

function w3c$dom$clearInterval() {
    clearInterval();
}

function w3c$dom$open(URL, name, specs, replace) {
    open(URL,name,specs,replace)
}

function w3c$dom$prompt(text, defaultText) {
    prompt(text,defaultText);
}

function w3c$dom$confirm(text) {
    confirm(text);
}

function w3c$dom$close() {
    close();
}
