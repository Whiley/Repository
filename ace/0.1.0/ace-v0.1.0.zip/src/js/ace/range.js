function ace$range$Range$IIII$Q5Range(sr,sc,er,ec) {
    return new ace.Range(sr,sc,er,ec);
}
