function ace$ace$edit$u2Q6stringQ7Element$Q6Editor(e) {
    return ace.edit(e);
}
